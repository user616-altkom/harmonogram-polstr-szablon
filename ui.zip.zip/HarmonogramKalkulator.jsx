// HarmonogramKalkulator — React + Tailwind, jeden plik, bez bibliotek UI.
// W projekcie: zamień linię z `React` na `import React, { useState } from "react";`
// i dodaj `export default HarmonogramKalkulator;` na końcu.
// Kolory i fonty czytane z tokenów (--color-*, --font-*) — działa też bez nich (fallbacki).
// Dodatkowe tokeny motywu: --kh-heading (nagłówki, kwoty), --kh-mark (akcent: aktywna opcja),
// --kh-mark-text (tekst w akcencie), --kh-band (pasek u góry ekranu).
const { useState } = React;

const API_URL = "/api/harmonogram";

// Motyw: grafit + granat, biel, turkusowy znacznik. Nadpisz przez prop `theme`.
const THEME = {
  "--color-bg": "#ffffff", "--color-surface": "#eef1f6", "--color-text": "#22262d",
  "--color-neutral-100": "#f5f6f8", "--color-neutral-200": "#e9ebef", "--color-neutral-300": "#d5d9e0",
  "--color-neutral-400": "#b4bac5", "--color-neutral-500": "#8e95a3", "--color-neutral-700": "#525a67",
  "--color-neutral-800": "#3a404b", "--color-accent": "#1b3566", "--color-accent-600": "#24427a",
  "--color-accent-700": "#142850", "--color-accent-100": "#e8edf6", "--color-accent-200": "#d3dcec",
  "--color-accent-2-700": "#b3261e", "--kh-heading": "#1b3566", "--kh-band": "#1b3566",
  "--kh-mark": "#12a5a8", "--kh-mark-text": "#0b6e73",
};

// 1234567.891 -> "1 234 567,89" (twarda spacja, zawsze z separatorem tysięcy)
function formatPLN(v) {
  const n = Number(v);
  if (!isFinite(n)) return "—";
  const [int, dec] = Math.abs(n).toFixed(2).split(".");
  return (n < 0 ? "−" : "") + int.replace(/\B(?=(\d{3})+(?!\d))/g, "\u00a0") + "," + dec;
}
const csvNum = (v) => Number(v).toFixed(2).replace(".", ",");
const formatDate = (s) => {
  const d = new Date(s);
  return isNaN(d) ? s : d.toLocaleDateString("pl-PL", { day: "2-digit", month: "2-digit", year: "numeric" });
};
const todayPlusMonth = () => {
  const d = new Date();
  d.setMonth(d.getMonth() + 1, 10);
  return d.toISOString().slice(0, 10);
};

const cx = (...c) => c.filter(Boolean).join(" ");
const T = {
  text: "text-[var(--color-text,#201e1d)]",
  muted: "text-[var(--color-neutral-700,#605d5d)]",
  input:
    "w-full h-11 px-3 rounded-[var(--radius-md,2px)] bg-[var(--color-neutral-100,#f8f4f4)] border border-[var(--color-neutral-300,#d7d3d3)] text-[var(--color-text,#201e1d)] tabular-nums outline-none hover:border-[var(--color-neutral-500,#9b9797)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-accent,#0088b0)]",
  label: "block text-[15px] mb-1.5 text-[var(--color-neutral-800,#444141)]",
  btnPrimary:
    "h-11 px-6 rounded-[var(--radius-md,2px)] bg-[var(--color-accent,#0088b0)] text-white font-semibold hover:bg-[var(--color-accent-600,#1186ac)] active:bg-[var(--color-accent-700,#006786)] disabled:opacity-45 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-accent,#0088b0)]",
  btnGhost:
    "h-11 px-4 rounded-[var(--radius-md,2px)] text-[var(--color-accent-700,#006786)] hover:bg-[var(--color-accent-100,#e9f8ff)] active:bg-[var(--color-accent-200,#cbeeff)] disabled:opacity-45 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-accent,#0088b0)]",
};

function Segmented({ name, value, options, onChange }) {
  return (
    <div role="radiogroup" aria-label={name} className="grid grid-flow-col auto-cols-fr gap-1 p-1 rounded-[var(--radius-md,2px)] bg-[var(--color-surface,#eae9e9)]">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="radio"
          aria-checked={value === o.value}
          onClick={() => onChange(o.value)}
          className={cx(
            "h-9 px-3 rounded-[var(--radius-sm,1px)] text-[15px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-accent,#0088b0)]",
            value === o.value
              ? "bg-[var(--color-bg,#f3f2f2)] text-[var(--color-text,#201e1d)] font-semibold [box-shadow:inset_0_-2px_0_var(--kh-mark,transparent),var(--shadow-sm,0_1px_2px_rgba(0,0,0,.08))]"
              : "text-[var(--color-neutral-700,#605d5d)] hover:text-[var(--color-text,#201e1d)]"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

// children: opcjonalna grafika (np. <img>) pokazywana, dopóki nie ma wyniku.
function HarmonogramKalkulator({ apiUrl = API_URL, theme, children }) {
  const [form, setForm] = useState({
    kwota: "450000",
    liczbaRat: "300",
    pierwszaRata: todayPlusMonth(),
    marza: "1.95",
    wskaznik: "POLSTR1M",
    typRat: "rowne",
  });
  const [nadplaty, setNadplaty] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [wynik, setWynik] = useState(null);
  const uid = (React.useId ? React.useId() : "kh").replace(/:/g, "");

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e && e.target ? e.target.value : e }));
  const addNadplata = () => setNadplaty((l) => [...l, { miesiac: "", kwota: "", tryb: "rata" }]);
  const setNad = (i, k, v) => setNadplaty((l) => l.map((n, j) => (j === i ? { ...n, [k]: v } : n)));
  const delNad = (i) => setNadplaty((l) => l.filter((_, j) => j !== i));

  function validate() {
    const kwota = parseFloat(String(form.kwota).replace(/\s/g, "").replace(",", "."));
    const n = parseInt(form.liczbaRat, 10);
    const marza = parseFloat(String(form.marza).replace(",", "."));
    if (!(kwota > 0)) return "Podaj kwotę kredytu większą od zera.";
    if (!(n > 0 && n <= 420)) return "Liczba rat musi mieścić się w zakresie 1–420.";
    if (!form.pierwszaRata) return "Podaj datę pierwszej raty.";
    if (!(marza >= 0)) return "Podaj marżę (pp).";
    for (const x of nadplaty) {
      const m = parseInt(x.miesiac, 10);
      if (!(m >= 1 && m <= n)) return `Miesiąc nadpłaty musi być w zakresie 1–${n}.`;
      if (!(parseFloat(String(x.kwota).replace(",", ".")) > 0)) return "Kwota nadpłaty musi być większa od zera.";
    }
    return "";
  }

  async function policz(e) {
    e.preventDefault();
    const err = validate();
    if (err) return setError(err);
    setError("");
    setLoading(true);
    const q = new URLSearchParams({
      kwota: String(form.kwota).replace(/\s/g, "").replace(",", "."),
      liczbaRat: form.liczbaRat,
      marza: String(form.marza).replace(",", "."),
      wskaznik: form.wskaznik,
      typRat: form.typRat,
      pierwszaRata: form.pierwszaRata,
    });
    // nadplaty=miesiac:kwota:tryb,… (tryb: rata | okres)
    if (nadplaty.length)
      q.set("nadplaty", nadplaty.map((n) => `${n.miesiac}:${String(n.kwota).replace(",", ".")}:${n.tryb}`).join(","));
    try {
      const res = await fetch(`${apiUrl}?${q.toString()}`, { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error(`Serwer zwrócił błąd ${res.status}.`);
      const data = await res.json();
      const raty = data.raty || [];
      setWynik({
        raty,
        rataPierwsza: data.rataPierwsza ?? raty[0]?.rata,
        rataOstatnia: data.rataOstatnia ?? raty[raty.length - 1]?.rata,
        sumaOdsetek: data.sumaOdsetek ?? raty.reduce((s, r) => s + Number(r.odsetki), 0),
        oprocentowanie: data.oprocentowanie,
      });
    } catch (ex) {
      setWynik(null);
      setError(ex.message || "Nie udało się pobrać harmonogramu.");
    } finally {
      setLoading(false);
    }
  }

  function eksportCSV() {
    if (!wynik) return;
    const rows = [["Nr", "Data", "Kapitał", "Odsetki", "Rata", "Nadpłata", "Saldo"]].concat(
      wynik.raty.map((r) => [r.nr, r.data, csvNum(r.kapital), csvNum(r.odsetki), csvNum(r.rata), csvNum(r.nadplata || 0), csvNum(r.saldo)])
    );
    const csv = "\ufeff" + rows.map((r) => r.join(";")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `harmonogram_${form.pierwszaRata}_${form.liczbaRat}rat.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div style={{ ...THEME, ...theme }} className={cx("min-h-full bg-[var(--color-bg,#f3f2f2)] [font-family:var(--font-body,Georgia,serif)] text-[17px] leading-relaxed", T.text)}>
      <div aria-hidden="true" className="h-1.5 bg-[var(--kh-band,transparent)]" />
      <div className="max-w-[1280px] px-6 md:px-10 py-10">
        <header className="mb-10">
          <p className={cx("text-[15px] mb-1", T.muted)}>Kredyt hipoteczny · oprocentowanie zmienne</p>
          <h1 className="[font-family:var(--font-heading,Georgia,serif)] font-semibold text-[40px] leading-tight tracking-tight text-[var(--kh-heading,var(--color-text,#201e1d))]">Harmonogram spłat</h1>
        </header>

        <div className="grid gap-12 lg:grid-cols-[360px_minmax(0,1fr)] items-start">
          <form onSubmit={policz} noValidate className="grid gap-5">
            <div>
              <label className={T.label} htmlFor={uid + "kwota"}>Kwota kredytu (PLN)</label>
              <input id={uid + "kwota"} inputMode="decimal" className={cx(T.input, "text-right")} value={form.kwota} onChange={set("kwota")} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={T.label} htmlFor={uid + "liczbaRat"}>Liczba rat</label>
                <input id={uid + "liczbaRat"} type="number" min="1" max="420" className={cx(T.input, "text-right")} value={form.liczbaRat} onChange={set("liczbaRat")} />
              </div>
              <div>
                <label className={T.label} htmlFor={uid + "marza"}>Marża (pp)</label>
                <input id={uid + "marza"} inputMode="decimal" className={cx(T.input, "text-right")} value={form.marza} onChange={set("marza")} />
              </div>
            </div>
            <div>
              <label className={T.label} htmlFor={uid + "pierwszaRata"}>Data pierwszej raty</label>
              <input id={uid + "pierwszaRata"} type="date" className={T.input} value={form.pierwszaRata} onChange={set("pierwszaRata")} />
            </div>
            <div>
              <span className={T.label}>Wskaźnik referencyjny</span>
              <Segmented name="Wskaźnik" value={form.wskaznik} onChange={set("wskaznik")}
                options={[{ value: "POLSTR1M", label: "POLSTR 1M" }, { value: "WIBOR3M", label: "WIBOR 3M" }]} />
            </div>
            <div>
              <span className={T.label}>Typ rat</span>
              <Segmented name="Typ rat" value={form.typRat} onChange={set("typRat")}
                options={[{ value: "rowne", label: "Równe" }, { value: "malejace", label: "Malejące" }]} />
            </div>

            <fieldset className="grid gap-3 mt-3">
              <legend className="[font-family:var(--font-heading,Georgia,serif)] font-semibold text-[20px] mb-2 text-[var(--kh-heading,var(--color-text,#201e1d))]">Nadpłaty</legend>
              {nadplaty.length === 0 && <p className={cx("text-[15px]", T.muted)}>Brak zaplanowanych nadpłat.</p>}
              {nadplaty.map((n, i) => (
                <div key={i} className="grid grid-cols-[72px_minmax(0,1fr)_40px] gap-2 items-end">
                  <div>
                    <label className="block text-[13px] mb-1 text-[var(--color-neutral-700,#605d5d)]" htmlFor={`${uid}nm${i}`}>Miesiąc</label>
                    <input id={`${uid}nm${i}`} type="number" min="1" className={cx(T.input, "text-right px-2")} value={n.miesiac} onChange={(e) => setNad(i, "miesiac", e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-[13px] mb-1 text-[var(--color-neutral-700,#605d5d)]" htmlFor={`${uid}nk${i}`}>Kwota (PLN)</label>
                    <input id={`${uid}nk${i}`} inputMode="decimal" className={cx(T.input, "text-right")} value={n.kwota} onChange={(e) => setNad(i, "kwota", e.target.value)} />
                  </div>
                  <button type="button" onClick={() => delNad(i)} aria-label={`Usuń nadpłatę ${i + 1}`}
                    className="h-11 w-10 rounded-[var(--radius-md,2px)] text-[22px] leading-none text-[var(--color-neutral-700,#605d5d)] hover:bg-[var(--color-surface,#eae9e9)] hover:text-[var(--color-text,#201e1d)] focus-visible:outline-2 focus-visible:outline-[var(--color-accent,#0088b0)]">×</button>
                  <div className="col-span-3 pb-2">
                    <Segmented name="Tryb nadpłaty" value={n.tryb} onChange={(v) => setNad(i, "tryb", v)}
                      options={[{ value: "rata", label: "Obniż ratę" }, { value: "okres", label: "Skróć okres" }]} />
                  </div>
                </div>
              ))}
              <div><button type="button" onClick={addNadplata} className={cx(T.btnGhost, "-ml-4")}>+ Dodaj nadpłatę</button></div>
            </fieldset>

            {error && <p role="alert" className="text-[15px] text-[var(--color-accent-2-700,#aa0b56)]">{error}</p>}
            <div className="mt-2">
              <button type="submit" disabled={loading} className={cx(T.btnPrimary, "w-full")}>{loading ? "Liczę…" : "Policz"}</button>
            </div>
          </form>

          <section aria-live="polite" className="min-w-0">
            {!wynik && !loading && (
              <div className="grid gap-6 pt-2">
                <p className={cx("max-w-[42ch] text-[19px]", T.muted)}>Uzupełnij parametry kredytu i wybierz „Policz”, aby wyświetlić harmonogram rat.</p>
                {children && <div className="max-w-[720px] aspect-[4/3] overflow-hidden rounded-[var(--radius-lg,4px)] bg-[var(--color-surface,#eae9e9)]">{children}</div>}
              </div>
            )}
            {loading && !wynik && <p className={cx("pt-2", T.muted)}>Pobieram harmonogram…</p>}
            {wynik && (
              <div className={cx("grid gap-10", loading && "opacity-60")}>
                <dl className="grid gap-x-10 gap-y-6 grid-cols-[repeat(auto-fit,minmax(180px,1fr))]">
                  {[
                    ["Rata pierwsza", wynik.rataPierwsza],
                    ["Rata ostatnia", wynik.rataOstatnia],
                    ["Suma odsetek", wynik.sumaOdsetek],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <dt className={cx("text-[15px]", T.muted)}>{k}</dt>
                      <dd className="[font-family:var(--font-heading,Georgia,serif)] font-semibold text-[32px] leading-tight tabular-nums whitespace-nowrap text-[var(--kh-heading,var(--color-text,#201e1d))]">
                        {formatPLN(v)} <span className={cx("text-[17px] font-normal", T.muted)}>PLN</span>
                      </dd>
                    </div>
                  ))}
                </dl>

                <div>
                  <div className="flex flex-wrap items-baseline justify-between gap-4 mb-3">
                    <h2 className="[font-family:var(--font-heading,Georgia,serif)] font-semibold text-[24px] text-[var(--kh-heading,var(--color-text,#201e1d))]">
                      Tabela rat <span className={cx("text-[17px] font-normal", T.muted)}>· {wynik.raty.length} rat{wynik.oprocentowanie != null && ` · oprocentowanie ${String(Number(wynik.oprocentowanie).toFixed(2)).replace(".", ",")}%`}</span>
                    </h2>
                    <button type="button" onClick={eksportCSV} className={T.btnGhost}>Eksport CSV</button>
                  </div>
                  <div className="max-h-[560px] overflow-auto">
                    <table className="w-full text-[15px] tabular-nums border-collapse">
                      <thead className="sticky top-0 bg-[var(--color-bg,#f3f2f2)]">
                        <tr className="text-[var(--color-neutral-700,#605d5d)] border-b border-[var(--color-neutral-400,#bab6b6)]">
                          <th className="text-right font-normal py-2 pr-4 w-12">Nr</th>
                          <th className="text-left font-normal py-2 pr-4">Data</th>
                          <th className="text-right font-normal py-2 pr-4">Kapitał</th>
                          <th className="text-right font-normal py-2 pr-4">Odsetki</th>
                          <th className="text-right font-normal py-2 pr-4">Rata</th>
                          <th className="text-right font-normal py-2">Saldo</th>
                        </tr>
                      </thead>
                      <tbody>
                        {wynik.raty.map((r) => (
                          <tr key={r.nr} className="border-b border-[var(--color-neutral-200,#eae7e7)] hover:bg-[var(--color-neutral-100,#f8f4f4)]">
                            <td className={cx("text-right py-2 pr-4", T.muted)}>{r.nr}</td>
                            <td className="py-2 pr-4 whitespace-nowrap">{formatDate(r.data)}</td>
                            <td className="text-right py-2 pr-4 whitespace-nowrap">{formatPLN(r.kapital)}</td>
                            <td className="text-right py-2 pr-4 whitespace-nowrap">{formatPLN(r.odsetki)}</td>
                            <td className="text-right py-2 pr-4 whitespace-nowrap font-semibold">{formatPLN(r.rata)}</td>
                            <td className="text-right py-2 whitespace-nowrap">
                              {formatPLN(r.saldo)}
                              {Number(r.nadplata) > 0 && (
                                <span className="block text-[13px] text-[var(--kh-mark-text,var(--color-accent-700,#006786))]">po nadpłacie {formatPLN(r.nadplata)}</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

if (typeof module !== "undefined") module.exports = { HarmonogramKalkulator };
