// Podgląd: podstawia GET /api/harmonogram lokalnym wyliczeniem (stawki wskaźników fikcyjne).
(function () {
  const STAWKI = { POLSTR1M: 4.02, WIBOR3M: 4.71 };
  const r2 = (x) => Math.round(x * 100) / 100;
  function addMonths(iso, k) {
    const [y, m, d] = iso.split("-").map(Number);
    const last = new Date(Date.UTC(y, m - 1 + k + 1, 0)).getUTCDate();
    return new Date(Date.UTC(y, m - 1 + k, Math.min(d, last))).toISOString().slice(0, 10);
  }
  function licz(p) {
    const P = +p.get("kwota"), n = +p.get("liczbaRat"), typ = p.get("typRat");
    const opr = (STAWKI[p.get("wskaznik")] || 0) + +p.get("marza");
    const i = opr / 100 / 12;
    const nad = {};
    (p.get("nadplaty") || "").split(",").filter(Boolean).forEach((s) => {
      const [m, k, t] = s.split(":"); nad[+m] = { kwota: +k, tryb: t };
    });
    const annuity = (S, k) => (i === 0 ? S / k : (S * i) / (1 - Math.pow(1 + i, -k)));
    let saldo = P, rataStala = annuity(P, n), kapStaly = P / n, raty = [];
    for (let nr = 1; nr <= n && saldo > 0.005; nr++) {
      const ods = r2(saldo * i);
      let kap = typ === "rowne" ? rataStala - ods : kapStaly;
      if (nr === n || kap > saldo) kap = saldo;
      kap = r2(kap);
      saldo = r2(saldo - kap);
      let nadplata = 0;
      const x = nad[nr];
      if (x && saldo > 0) {
        nadplata = Math.min(x.kwota, saldo);
        saldo = r2(saldo - nadplata);
        if (x.tryb === "rata") {
          rataStala = annuity(saldo, n - nr);
          kapStaly = saldo / (n - nr);
        }
      }
      raty.push({ nr, data: addMonths(p.get("pierwszaRata"), nr - 1), kapital: kap, odsetki: ods, rata: r2(kap + ods), nadplata, saldo });
    }
    return {
      oprocentowanie: opr,
      rataPierwsza: raty[0].rata,
      rataOstatnia: raty[raty.length - 1].rata,
      sumaOdsetek: r2(raty.reduce((s, r) => s + r.odsetki, 0)),
      raty,
    };
  }
  const orig = window.fetch.bind(window);
  window.fetch = function (url, opts) {
    const u = new URL(String(url), location.href);
    if (!u.pathname.endsWith("/api/harmonogram")) return orig(url, opts);
    return new Promise((res) => setTimeout(() => res(new Response(JSON.stringify(licz(u.searchParams)), {
      status: 200, headers: { "Content-Type": "application/json" },
    })), 350));
  };
})();
